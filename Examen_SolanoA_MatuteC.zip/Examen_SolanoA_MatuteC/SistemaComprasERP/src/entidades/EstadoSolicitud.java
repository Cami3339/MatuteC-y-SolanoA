package entidades;

public enum EstadoSolicitud {
    SOLICITADA,
    EN_REVISION,
    APROBADA,
    RECHAZADA
}
