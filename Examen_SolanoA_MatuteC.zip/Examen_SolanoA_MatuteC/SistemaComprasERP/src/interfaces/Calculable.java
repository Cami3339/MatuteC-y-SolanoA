package interfaces;

public interface Calculable {
    double calcularCostoTotal(int cantidad);
}
