# Sistema de Gestión de Compras ERP

## Integrantes:
- Camila Matute
- Andrés Solano

## Descripción:
Este proyecto simula un módulo de compras de un sistema ERP, permitiendo registrar proveedores, productos y calcular totales.

## Instrucciones de ejecución:
1. Compilar con: `javac src/**/*.java`
2. Ejecutar con: `java -cp src Main`